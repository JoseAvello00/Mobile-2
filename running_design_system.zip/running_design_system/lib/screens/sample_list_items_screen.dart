import 'package:flutter/material.dart';

import '../common/showcase_scaffold.dart';
import '../components/list_items/list_item_component.dart';
import '../components/list_items/list_item_factory.dart';

/// Catálogo do componente **Card & List Item**: card de rota (grid da
/// Home) e linha de treino planejado (Plano de Treino), em diferentes
/// estados.
class SampleListItemsScreen extends StatelessWidget {
  const SampleListItemsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ComponentCatalogScaffold(
      title: 'Card & List Item',
      description: 'Card de rota e linha de treino planejado, em diferentes estados.',
      sections: ListItemFactory.showcaseCatalog(),
      itemBuilder: (context, viewModel) => ListItemComponent(viewModel: viewModel),
    );
  }
}

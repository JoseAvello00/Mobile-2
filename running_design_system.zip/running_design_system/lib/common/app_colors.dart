import 'package:flutter/material.dart';

/// Paleta bruta de cores — a única fonte de verdade dos valores hexadecimais.
///
/// A seção **Light** foi definida para o tema **Corrida**, inspirada no kit
/// de wireframes de UI mobile do Figma (Community) usado como ponto de
/// partida deste projeto. Observação importante: o link do Figma fornecido
/// aponta para um arquivo de wireframes (baixa fidelidade / escala de
/// cinza) protegido contra acesso automatizado, então não foi possível
/// extrair valores hexadecimais exatos dele — a paleta abaixo é uma
/// proposta de cor para um app de corrida (energia, ritmo, performance),
/// pronta para ser ajustada assim que você tiver os valores exatos do
/// arquivo (basta editar as constantes aqui).
///
/// A seção **Dark** é uma extensão do template — segue as mesmas boas
/// práticas de contraste (WCAG) da versão original.
///
/// Este arquivo não deve ser referenciado diretamente pelos componentes.
/// Os componentes leem cores semânticas via `context.colors` (ver
/// `app_color_tokens.dart`), que mapeia estes valores brutos para papéis
/// (background, surface, texto, borda etc.) de acordo com o tema ativo.
class AppColors {
  const AppColors._();

  // ---------------------------------------------------------------------
  // Light — proposta de paleta para o tema Corrida
  // ---------------------------------------------------------------------

  /// 01 — Laranja-avermelhado (energia, ritmo, marca).
  static const Color primary = Color(0xFFFF5A36);

  /// 02 — Pêssego claro (fundo de chip selecionado).
  static const Color secondaryLight = Color(0xFFFFE1D4);

  /// 03 — Quase preto (texto principal).
  static const Color darkLight = Color(0xFF1E1E1E);

  /// 04 — Cinza claro (bordas/divisores).
  static const Color greyLight = Color(0xFFE4E4E4);

  /// 05 — Cinza neutro bem claro (fundo padrão, no espírito do wireframe).
  static const Color creamLight = Color(0xFFF5F6F5);

  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF000000);
  static const Color textSecondaryLight = Color(0xFF8A8A8A);
  static const Color dangerLight = Color(0xFFE5484D);
  static const Color successLight = Color(0xFF2FA84F);

  // ---------------------------------------------------------------------
  // Dark — extensão do template
  // ---------------------------------------------------------------------

  static const Color backgroundDark = Color(0xFF14171A);
  static const Color surfaceDark = Color(0xFF1E2226);
  static const Color borderDark = Color(0xFF2D3236);
  static const Color secondaryDark = Color(0xFF40291F);
  static const Color onSecondaryDark = Color(0xFFFFB294);
  static const Color textPrimaryDark = Color(0xFFF2F1EF);
  static const Color textSecondaryDark = Color(0xFFA9ADB0);
  static const Color heroBackgroundDark = Color(0xFF0D0F11);
  static const Color dangerDark = Color(0xFFF0837F);
  static const Color successDark = Color(0xFF69C285);
}

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Escala tipográfica do sistema de design.
///
/// A fonte usada é **Inter** (Google Font gratuita) — uma escolha segura
/// e neutra, coerente com a origem deste template em um kit de
/// wireframes (baixa fidelidade). Não foi possível confirmar a fonte
/// exata do arquivo Figma de origem (acesso automatizado bloqueado pelo
/// robots.txt do Figma), então troque por `GoogleFonts.<fonte>` aqui
/// caso tenha a especificação exata do design.
///
/// IMPORTANTE: nenhum estilo aqui define `color`. Cor é um token de tema
/// (claro/escuro) e não de tipografia — os componentes aplicam a cor
/// correta via `.copyWith(color: context.colors.onSurface)` (ou o papel
/// semântico equivalente). Isso é o que permite a mesma escala
/// tipográfica funcionar em ambos os temas sem duplicação.
class AppTypography {
  const AppTypography._();

  static TextStyle _sans({
    required double fontSize,
    required FontWeight fontWeight,
    double? height,
    double? letterSpacing,
  }) {
    return GoogleFonts.inter(
      fontSize: fontSize,
      fontWeight: fontWeight,
      height: height,
      letterSpacing: letterSpacing,
    );
  }

  /// Título grande de tela (ex.: nome da rota no Detail).
  static TextStyle get headingLarge =>
      _sans(fontSize: 24, fontWeight: FontWeight.w700, height: 1.2);

  /// Título de seção (ex.: "Descrição", "Distância").
  static TextStyle get headingMedium =>
      _sans(fontSize: 18, fontWeight: FontWeight.w700, height: 1.3);

  /// Título de card de rota/treino (ex.: "Parque Ibirapuera Loop").
  static TextStyle get titleSmall =>
      _sans(fontSize: 16, fontWeight: FontWeight.w600, height: 1.3);

  /// Corpo de texto padrão (descrições, endereços).
  static TextStyle get bodyMedium =>
      _sans(fontSize: 14, fontWeight: FontWeight.w400, height: 1.5);

  /// Corpo de texto pequeno (subtítulos de card, ex.: "5.2 km • Fácil").
  static TextStyle get bodySmall =>
      _sans(fontSize: 13, fontWeight: FontWeight.w400, height: 1.4);

  /// Legenda/caption (avaliações, contadores, rótulos de exemplo).
  static TextStyle get caption =>
      _sans(fontSize: 12, fontWeight: FontWeight.w500, height: 1.3);

  /// Rótulo pequeno em maiúsculas, usado como cabeçalho de seção do
  /// catálogo (ex.: "COLOR / PRIMARY").
  static TextStyle get overline => _sans(
        fontSize: 11,
        fontWeight: FontWeight.w700,
        height: 1.2,
        letterSpacing: 0.8,
      );

  /// Métrica em destaque no card (ex.: "32 min", "5.2 km").
  static TextStyle get metric => _sans(fontSize: 18, fontWeight: FontWeight.w700);

  /// Texto de botão grande.
  static TextStyle get buttonLarge => _sans(fontSize: 16, fontWeight: FontWeight.w600);

  /// Texto de botão pequeno / chip.
  static TextStyle get buttonSmall => _sans(fontSize: 13, fontWeight: FontWeight.w600);

  /// Label de navegação inferior.
  static TextStyle get navLabel => _sans(fontSize: 11, fontWeight: FontWeight.w500);
}

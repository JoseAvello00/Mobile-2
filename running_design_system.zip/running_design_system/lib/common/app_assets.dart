/// Caminhos de imagens usados pelos componentes de demonstração.
///
/// Este template NÃO inclui arquivos binários do Figma. Em vez disso,
/// aponta para `assets/images/...`, que você deve preencher exportando
/// as imagens reais do seu design (foto de rota, esteira, corredor etc).
///
/// Todos os componentes que usam [AppAssets] fazem fallback automático
/// para um placeholder visual (ver `_RunImage` em
/// `components/list_items`) caso o arquivo não exista — assim o template
/// roda "out of the box" mesmo sem os assets reais.
class AppAssets {
  const AppAssets._();

  static const String _base = 'assets/images';

  static const String parkLoopRun = '$_base/park_loop_run.png';
  static const String trailRun = '$_base/trail_run.png';
  static const String beachRun = '$_base/beach_run.png';
  static const String treadmillRun = '$_base/treadmill_run.png';
  static const String promoBanner = '$_base/promo_banner.png';
  static const String avatarPlaceholder = '$_base/avatar_placeholder.png';
}

import 'package:flutter/material.dart';

import '../../common/app_assets.dart';
import '../../common/showcase_models.dart';
import 'list_item_viewmodel.dart';

/// O Criador de Variantes de cards de rota / linhas de treino.
class ListItemFactory {
  const ListItemFactory._();

  static ListItemViewModel routeCard({
    required String title,
    String? subtitle,
    required String metric,
    double? rating,
    int? reviewCount,
    String? imagePath,
    bool isAvailable = true,
    VoidCallback? onTap,
    VoidCallback? onAdd,
  }) {
    return ListItemViewModel(
      title: title,
      subtitle: subtitle,
      metric: metric,
      rating: rating,
      reviewCount: reviewCount,
      imagePath: imagePath,
      variant: ListItemVariant.routeCard,
      isAvailable: isAvailable,
      onTap: onTap,
      onAdd: onAdd,
    );
  }

  static ListItemViewModel sessionLine({
    required String title,
    required String metric,
    String? imagePath,
    int quantity = 1,
    ValueChanged<int>? onQuantityChanged,
  }) {
    return ListItemViewModel(
      title: title,
      metric: metric,
      imagePath: imagePath,
      variant: ListItemVariant.sessionLine,
      quantity: quantity,
      onQuantityChanged: onQuantityChanged,
    );
  }

  /// Rotas "reais" (nomes/métricas/ratings) usadas no [sample_screen] e
  /// no showcase — inspiradas em rotas comuns de apps de corrida.
  static List<ListItemViewModel> demoRuns() {
    return [
      routeCard(
        title: 'Parque Ibirapuera Loop',
        subtitle: '5.2 km • Fácil',
        metric: '32 min',
        rating: 4.8,
        reviewCount: 230,
        imagePath: AppAssets.parkLoopRun,
      ),
      routeCard(
        title: 'Trilha da Serra',
        subtitle: '10 km • Difícil',
        metric: '58 min',
        rating: 4.7,
        reviewCount: 189,
        imagePath: AppAssets.trailRun,
      ),
      routeCard(
        title: 'Orla da Praia',
        subtitle: '7 km • Moderado',
        metric: '40 min',
        rating: 4.6,
        reviewCount: 142,
        imagePath: AppAssets.beachRun,
      ),
      routeCard(
        title: 'Esteira Intervalado',
        subtitle: '5 km • Moderado',
        metric: '28 min',
        rating: 4.5,
        reviewCount: 98,
        imagePath: AppAssets.treadmillRun,
      ),
    ];
  }

  /// Catálogo completo usado por `sample_list_items_screen`.
  static List<ShowcaseSection<ListItemViewModel>> showcaseCatalog() {
    return [
      ShowcaseSection(
        title: 'Route Card',
        description: 'Card do grid da Home, com variações de estado.',
        items: [
          ShowcaseItem(caption: 'Disponível', viewModel: demoRuns().first),
          ShowcaseItem(
            caption: 'Sem avaliação',
            viewModel: routeCard(title: 'Volta no Quarteirão', metric: '18 min'),
          ),
          ShowcaseItem(
            caption: 'Indisponível (desabilitado)',
            viewModel: routeCard(
              title: 'Corrida Noturna',
              metric: '45 min',
              rating: 4.6,
              isAvailable: false,
            ),
          ),
        ],
      ),
      ShowcaseSection(
        title: 'Session Line',
        description: 'Linha compacta usada na tela de Plano de Treino, com stepper de séries.',
        items: [
          ShowcaseItem(
            caption: '1 série',
            viewModel: sessionLine(title: 'Tiro de 400m', metric: '1:25 min/série', quantity: 1),
          ),
          ShowcaseItem(
            caption: '3 séries',
            viewModel: sessionLine(title: 'Subida de Rampa', metric: '2:10 min/série', quantity: 3),
          ),
        ],
      ),
    ];
  }
}

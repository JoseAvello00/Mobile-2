import 'package:flutter/material.dart';

/// - [routeCard]   → card do grid da Home (imagem, badge de rating,
///                    nome da rota, subtítulo, métrica, botão de
///                    adicionar ao plano).
/// - [sessionLine] → linha compacta usada na tela de Plano de Treino
///                    (imagem pequena, nome+métrica, stepper de séries).
enum ListItemVariant { routeCard, sessionLine }

@immutable
class ListItemViewModel {
  final String title;
  final String? subtitle;

  /// Métrica em destaque do card (ex.: "32 min", "5.2 km").
  final String metric;
  final double? rating;
  final int? reviewCount;
  final String? imagePath;
  final ListItemVariant variant;
  final bool isAvailable;
  final int quantity;
  final VoidCallback? onTap;
  final VoidCallback? onAdd;
  final ValueChanged<int>? onQuantityChanged;

  const ListItemViewModel({
    required this.title,
    this.subtitle,
    required this.metric,
    this.rating,
    this.reviewCount,
    this.imagePath,
    this.variant = ListItemVariant.routeCard,
    this.isAvailable = true,
    this.quantity = 1,
    this.onTap,
    this.onAdd,
    this.onQuantityChanged,
  });

  ListItemViewModel copyWith({
    String? title,
    String? subtitle,
    String? metric,
    double? rating,
    int? reviewCount,
    String? imagePath,
    ListItemVariant? variant,
    bool? isAvailable,
    int? quantity,
    VoidCallback? onTap,
    VoidCallback? onAdd,
    ValueChanged<int>? onQuantityChanged,
  }) {
    return ListItemViewModel(
      title: title ?? this.title,
      subtitle: subtitle ?? this.subtitle,
      metric: metric ?? this.metric,
      rating: rating ?? this.rating,
      reviewCount: reviewCount ?? this.reviewCount,
      imagePath: imagePath ?? this.imagePath,
      variant: variant ?? this.variant,
      isAvailable: isAvailable ?? this.isAvailable,
      quantity: quantity ?? this.quantity,
      onTap: onTap ?? this.onTap,
      onAdd: onAdd ?? this.onAdd,
      onQuantityChanged: onQuantityChanged ?? this.onQuantityChanged,
    );
  }
}

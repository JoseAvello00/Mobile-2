import 'package:flutter/material.dart';

import '../../common/showcase_models.dart';
import 'tab_bar_viewmodel.dart';

/// O Criador de Variantes da barra de navegação.
class TabBarFactory {
  const TabBarFactory._();

  /// Abas de categoria da Home ("Todas", "Trilha", "Rua", "Esteira").
  static TabBarViewModel categoryTabs({
    List<String> labels = const ['Todas', 'Trilha', 'Rua', 'Esteira'],
    int activeIndex = 0,
    ValueChanged<int>? onItemSelected,
  }) {
    return TabBarViewModel(
      variant: TabBarVariant.categoryChips,
      items: [for (final label in labels) TabBarItemViewModel(label: label)],
      activeIndex: activeIndex,
      onItemSelected: onItemSelected,
    );
  }

  /// Navegação inferior fixa (Home / Stats / Activity / Profile).
  static TabBarViewModel bottomNav({
    int activeIndex = 0,
    ValueChanged<int>? onItemSelected,
  }) {
    return TabBarViewModel(
      variant: TabBarVariant.bottomNavigation,
      items: const [
        TabBarItemViewModel(label: 'Home', icon: Icons.home_rounded),
        TabBarItemViewModel(label: 'Stats', icon: Icons.insights_rounded),
        TabBarItemViewModel(label: 'Activity', icon: Icons.directions_run_rounded),
        TabBarItemViewModel(label: 'Profile', icon: Icons.person_outline_rounded),
      ],
      activeIndex: activeIndex,
      onItemSelected: onItemSelected,
    );
  }

  /// Catálogo completo usado por `sample_tab_bar_screen`.
  static List<ShowcaseSection<TabBarViewModel>> showcaseCatalog() {
    return [
      ShowcaseSection(
        title: 'Category Chips',
        description: 'Abas de categoria no topo da Home, com item ativo variando.',
        items: [
          ShowcaseItem(caption: 'Ativo: Todas', viewModel: categoryTabs(activeIndex: 0)),
          ShowcaseItem(caption: 'Ativo: Rua', viewModel: categoryTabs(activeIndex: 2)),
        ],
      ),
      ShowcaseSection(
        title: 'Bottom Navigation',
        description: 'Barra fixa inferior com indicador do item ativo.',
        items: [
          ShowcaseItem(caption: 'Home ativo', viewModel: bottomNav(activeIndex: 0)),
          ShowcaseItem(caption: 'Stats ativo', viewModel: bottomNav(activeIndex: 1)),
          ShowcaseItem(caption: 'Activity ativo', viewModel: bottomNav(activeIndex: 2)),
        ],
      ),
    ];
  }
}

# Running Design System — Catálogo de Componentes

Catálogo de sistema de design em Flutter/Dart, tema **Corrida**,
reestruturado a partir do template
**[`coffee_design_system`](../coffee_design_system)** e inspirado no kit
**["📲 Wireframes for mobile UI design" (Community)](https://www.figma.com/design/aE5UvFW5gu3gcV1WBZDAiF/%F0%9F%93%B2Wireframes-for-mobile-UI-design--Community-)**
do Figma.

> Este projeto é um **catálogo vivo de design system** — como um
> Storybook para Flutter. Ele existe para documentar e exercitar cada
> token e cada variação de componente (cor, tamanho, estado, tema claro
> e escuro), não para ser o app final. Use-o como referência/ponto de
> partida ao construir o produto real.

### ⚠️ Nota importante sobre a origem do design

O link do Figma fornecido é um arquivo de **wireframes** (protótipo de
baixa fidelidade, normalmente em escala de cinza) e está protegido
contra leitura automatizada (robots.txt do Figma bloqueia acesso direto,
e não havia uma sessão/plugin do Figma conectado nesta conversa capaz de
abrir o arquivo). Por isso, **não foi possível extrair valores
hexadecimais exatos** desse arquivo específico.

O que este template faz, então, é reaproveitar a **arquitetura completa**
do `coffee_design_system` (mesmo padrão Component/ViewModel/Factory,
mesmas ferramentas, mesma estrutura de pastas e catálogo) e propor uma
**paleta de cor e conteúdo adequados a um app de corrida**, prontos para
serem ajustados assim que você tiver os valores exatos do arquivo Figma
(por exemplo, abrindo o frame de estilo/cores dele e me colando os
códigos hex, ou exportando os tokens via plugin "Design Tokens").

---

## 1. O que o catálogo mostra

| Seção | Conteúdo |
|---|---|
| **Foundations** | Todos os tokens de cor do tema ativo + a escala tipográfica (Inter) |
| **Button** | `primary`, `secondary` e `icon` — cada um por tamanho e estado. O botão de **adicionar ao plano** é um Icon Button e está catalogado explicitamente |
| **Selectable Item** | Chips de seleção (não são botões de ação): seletor de distância `5K/10K/21K` e abas de categoria |
| **Navigation** | Abas de categoria (compostas a partir do Selectable Item) e navegação inferior |
| **Card & List Item** | Card de rota e linha de treino planejado, em diferentes estados |
| **Composição de Uso** | Os componentes acima combinados em uma tela real (Home) |

Um botão no canto superior direito de **qualquer** tela alterna entre
tema **claro** e **escuro** instantaneamente — todos os tokens e
componentes reagem, porque nenhuma cor está fixa no código: tudo é lido
por papel semântico (`context.colors.primary`, `context.colors.surface`
etc.), nunca por valor hexadecimal direto.

---

## 2. Tokens de cor: claro e escuro

| Token semântico | Light (proposta) | Dark (extensão do template) |
|---|---|---|
| `primary` | `#FF5A36` | `#FF5A36` (mesma cor de marca) |
| `onPrimary` | `#FFFFFF` | `#FFFFFF` |
| `secondary` | `#FFE1D4` | `#40291F` |
| `onSecondary` | `#FF5A36` | `#FFB294` |
| `background` | `#F5F6F5` | `#14171A` |
| `surface` | `#FFFFFF` | `#1E2226` |
| `onSurface` | `#1E1E1E` | `#F2F1EF` |
| `textSecondary` | `#8A8A8A` | `#A9ADB0` |
| `border` | `#E4E4E4` | `#2D3236` |
| `heroBackground` | `#1E1E1E` | `#0D0F11` |
| `danger` / `success` | `#E5484D` / `#2FA84F` | `#F0837F` / `#69C285` |

Tudo isso vive em `lib/common/app_colors.dart` (paleta bruta) e
`lib/common/app_color_tokens.dart` (mapeamento semântico por tema). Se
você conseguir abrir o arquivo Figma manualmente e me passar os valores
reais (ou um print do "Color Guide"), eu atualizo essas duas constantes
e todo o app se ajusta automaticamente — não é preciso tocar em nenhum
componente.

---

## 3. Padrão de projeto: Component / ViewModel / Factory

Idêntico ao template original. Cada componente reutilizável em
`lib/components/<nome>/` segue sempre a mesma estrutura de 3 arquivos —
um mini-MVVM combinado com o padrão **Factory** para criação de
variantes:

```
components/<nome>/
├── <nome>_component.dart    # A UI Visual — StatelessWidget "burro"
├── <nome>_viewmodel.dart    # O Estado e Dados — classe imutável
└── <nome>_factory.dart      # O Criador de Variantes — métodos estáticos
```

- **`*_viewmodel.dart`**: classe `@immutable` com `copyWith`, descreve
  completamente UMA instância do componente. Sem lógica de UI, sem
  regra de negócio.
- **`*_component.dart`**: `StatelessWidget` que só desenha o ViewModel
  recebido, lendo cor por papel semântico via `context.colors` (nunca
  `Color(0xFF...)` direto) — é isso que faz o tema escuro funcionar em
  todo o sistema automaticamente.
- **`*_factory.dart`**: métodos estáticos que sabem montar as
  combinações válidas de ViewModel, e um `showcaseCatalog()` — usado
  pelas telas de catálogo para renderizar TODAS as variações
  automaticamente.

### Por que `Button` e `Selectable Item` são componentes separados

Um botão **dispara uma ação** (Iniciar Corrida, adicionar ao plano,
voltar). Um item selecionável **representa um estado dentro de um
grupo** (qual distância está escolhida, qual categoria está ativa). São
conceitos semanticamente diferentes — por isso vivem em componentes e
catálogos próprios (`action_button/` e `selectable_chip/`), mesmo
compartilhando influências visuais (ambos usam formato de pílula).

### Como adicionar um novo componente

1. Crie `lib/components/meu_componente/` com os 3 arquivos no mesmo
   padrão (copie um existente como esqueleto).
2. Leia cor sempre via `context.colors.<papel>` — nunca hardcode.
3. Implemente `showcaseCatalog()` na factory retornando
   `List<ShowcaseSection<MeuComponenteViewModel>>`.
4. Crie `lib/screens/<nome>_screen.dart` usando `ComponentCatalogScaffold`
   (veja `lib/common/showcase_scaffold.dart`) — normalmente ~15 linhas.
5. Adicione uma entrada em `DesignSystemHomeScreen` (`lib/main.dart`).

---

## 4. Estrutura de pastas

```
lib/
├── common/
│   ├── app_colors.dart          # Paleta bruta (proposta light + extensão dark)
│   ├── app_color_tokens.dart    # Tokens semânticos por tema (ThemeExtension)
│   ├── app_theme.dart           # Monta ThemeData light/dark + context.colors
│   ├── theme_controller.dart    # Estado global do tema (claro/escuro)
│   ├── theme_toggle_button.dart # Botão de alternância reutilizável
│   ├── app_typography.dart      # Escala tipográfica (Inter), sem cor fixa
│   ├── app_assets.dart          # Caminhos de imagens
│   ├── showcase_models.dart     # Modelo genérico de "seção de exemplos"
│   └── showcase_scaffold.dart   # Layout genérico das telas de catálogo
├── components/
│   ├── action_button/       # Botão de ação: primary, secondary, icon (inclui "adicionar ao plano")
│   ├── selectable_chip/     # Item selecionável: seletor de distância, aba de categoria
│   ├── tab_bar/             # Navegação: categorias (compostas de selectable_chip) + bottom nav
│   └── list_items/          # Card de rota e linha de treino planejado
├── screens/
│   ├── foundations_screen.dart           # Catálogo: cores + tipografia
│   ├── sample_action_button_screen.dart  # Catálogo: Button
│   ├── selectable_items_screen.dart      # Catálogo: Selectable Item
│   ├── sample_tab_bar_screen.dart        # Catálogo: Navigation
│   ├── sample_list_items_screen.dart     # Catálogo: Card & List Item
│   └── sample_screen.dart                # Composição de uso (Home real)
└── main.dart                  # Landing page do catálogo + tema global
```

---

## 5. Como rodar

### Localmente (Android Studio / VS Code / terminal)

```bash
flutter pub get
flutter run
```

Se este for o **primeiro build** e a pasta não tiver `android/`, `ios/`
etc. (este template só contém o código Dart, `pubspec.yaml` e assets —
por design, para ficar independente de plataforma), gere o scaffolding
de plataforma uma vez, na raiz do projeto:

```bash
flutter create .
```

Isso cria `android/`, `ios/`, `web/` etc. sem sobrescrever o `lib/` já
existente. Depois disso, abra a pasta no **Android Studio** (File → Open),
deixe o Gradle sincronizar, escolha um emulador ou dispositivo físico e
rode com o botão ▶️ (ou `flutter run`).

O app abre na landing do catálogo, organizada em **Foundations**,
**Components** e **Preview**. O ícone de sol/lua na barra superior de
qualquer tela alterna entre os temas claro e escuro.

### Assets de imagem

`lib/common/app_assets.dart` aponta para `assets/images/<nome>.png`.
Exporte imagens reais (fotos de rota, trilha, praia, esteira) para essa
pasta, ou deixe como está: todo componente de imagem tem `errorBuilder`
com fallback visual, então o catálogo roda "out of the box" mesmo sem
os assets.

### Fonte

A tipografia usa [`google_fonts`](https://pub.dev/packages/google_fonts)
para carregar **Inter** dinamicamente. Para embutir a fonte localmente
(sem depender de rede em tempo de execução), baixe os arquivos em
[fonts.google.com/specimen/Inter](https://fonts.google.com/specimen/Inter),
declare em `pubspec.yaml` e troque `GoogleFonts.inter(...)` por
`TextStyle(fontFamily: 'Inter', ...)` em `app_typography.dart`.

---

## 6. Customizando o template

- **Trocar a paleta**: edite `app_colors.dart` (valores brutos) e/ou
  `app_color_tokens.dart` (mapeamento semântico). Todo o app — em
  ambos os temas — se atualiza sozinho.
- **Adicionar uma variação de botão**: adicione um método/entrada na
  `ActionButtonFactory` e no `showcaseCatalog()`.
- **Trocar as rotas de exemplo**: edite `ListItemFactory.demoRuns()`.
- **Ajustar a Home composta**: `lib/screens/sample_screen.dart`.

---

## 7. Como comitar no Git

Na raiz do projeto:

```bash
git init
git add .
git commit -m "feat: Running Design System (tema corrida, baseado no Coffee Design System)"
# depois de criar o repositório remoto (GitHub/GitLab/Bitbucket):
git remote add origin <url-do-seu-repositorio>
git branch -M main
git push -u origin main
```

Sugestão de `.gitignore` (Flutter padrão) já é gerado automaticamente
quando você roda `flutter create .` — confira se `build/`, `.dart_tool/`
e arquivos de IDE estão ignorados antes do primeiro commit.

---

## 8. Créditos

Tema e arquitetura: reestruturado a partir do template **Coffee Design
System** (por sua vez baseado no arquivo Community "JavaGem — Coffee
Shop Mobile App Design"). Inspiração de tema: kit
**"📲 Wireframes for mobile UI design"**, arquivo Community do Figma.
Este template reimplementa tokens e componentes em código Dart para
fins de estudo/demonstração de arquitetura Flutter — não redistribui
nenhum asset binário original de arquivos do Figma.

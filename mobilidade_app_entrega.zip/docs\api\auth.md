# API de autenticação

## Login

Autentica uma pessoa usuária e devolve o token que será usado nas próximas
requisições. O app consome este contrato em `ServerLoginReal`.

| Item | Valor |
| --- | --- |
| Método | `POST` |
| Rota | `/auth/login` |
| Content-Type | `application/json` |
| Autenticação | Não necessária |

### Request

```json
{
  "email": "ana@carteira.dev",
  "password": "123456"
}
```

| Campo | Tipo | Obrigatório | Descrição |
| --- | --- | --- | --- |
| `email` | string | Sim | E-mail da conta. |
| `password` | string | Sim | Senha da conta. |

### Response — sucesso (`200 OK`)

```json
{
  "token": "eyJhbGciOiJIUzI1NiJ9...",
  "user": {
    "name": "Ana Ribeiro"
  }
}
```

| Campo | Tipo | Descrição |
| --- | --- | --- |
| `token` | string | Token de acesso da sessão. |
| `user.name` | string | Nome a ser exibido para a pessoa autenticada. |

### Responses de erro

| Status | Quando ocorre | Tratamento no app |
| --- | --- | --- |
| `401 Unauthorized` | E-mail ou senha inválidos. | Exibe “E-mail ou senha incorretos.” |
| `422 Unprocessable Entity` | E-mail ou senha ausentes ou inválidos. | Exibe “Informe e-mail e senha.” |
| `5xx` | Falha inesperada no servidor. | Exibe o status retornado. |

## Ambiente local

`ServerLoginReal` usa `http://localhost:8080` em desktop e web. No emulador
Android, usa `http://10.0.2.2:8080`, que aponta para a máquina hospedeira.
O tempo limite da requisição é de dez segundos.

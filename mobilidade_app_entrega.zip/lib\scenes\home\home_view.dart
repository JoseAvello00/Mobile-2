import 'package:carteira_design_system/carteira_design_system.dart';
import 'package:flutter/material.dart';

import 'home_view_model.dart';
import 'ride_option.dart';

class HomeView extends StatefulWidget {
  const HomeView({required this.viewModel, super.key});

  final HomeViewModel viewModel;

  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  @override
  void dispose() {
    widget.viewModel.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final viewModel = widget.viewModel;
    final scheme = Theme.of(context).colorScheme;

    return Scaffold(
      body: Stack(
        children: [
          const Positioned.fill(child: _MapPreview()),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(AppSpacing.lg),
              child: Align(
                alignment: Alignment.topRight,
                child: CircleAvatar(
                  backgroundColor: scheme.surface,
                  child: IconButton(
                    tooltip: 'Perfil',
                    onPressed: () {},
                    icon: const Icon(Icons.person_outline),
                  ),
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: ListenableBuilder(
              listenable: viewModel,
              builder: (context, _) => _RidePanel(viewModel: viewModel),
            ),
          ),
        ],
      ),
    );
  }
}

class _RidePanel extends StatelessWidget {
  const _RidePanel({required this.viewModel});

  final HomeViewModel viewModel;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final selectedRide = viewModel.selectedRide;

    return Material(
      color: scheme.surface,
      borderRadius: const BorderRadius.vertical(
        top: Radius.circular(AppRadius.lg),
      ),
      elevation: 12,
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.lg,
            AppSpacing.md,
            AppSpacing.lg,
            AppSpacing.lg,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 36,
                  height: 4,
                  decoration: BoxDecoration(
                    color: scheme.outline,
                    borderRadius: AppRadius.pillAll,
                  ),
                ),
              ),
              const Gap.lg(),
              Text(
                'Para onde vamos?',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const Gap.md(),
              AppTextField(
                key: const Key('home_destination'),
                label: 'Destino',
                hint: 'Digite um endereço ou lugar',
                prefixIcon: Icons.search,
                textInputAction: TextInputAction.done,
                onChanged: viewModel.updateDestination,
              ),
              const Gap.lg(),
              Text(
                'Escolha sua corrida',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const Gap.md(),
              SizedBox(
                height: 106,
                child: ListView.separated(
                  key: const Key('ride_options'),
                  scrollDirection: Axis.horizontal,
                  itemCount: viewModel.options.length,
                  separatorBuilder: (_, _) =>
                      const SizedBox(width: AppSpacing.sm),
                  itemBuilder: (context, index) {
                    final option = viewModel.options[index];
                    return _RideOptionCard(
                      option: option,
                      selected: option.id == selectedRide?.id,
                      onTap: () => viewModel.selectRide(option),
                    );
                  },
                ),
              ),
              const Gap.lg(),
              if (viewModel.rideRequested && selectedRide != null) ...[
                _RequestConfirmed(
                  destination: viewModel.destination,
                  ride: selectedRide,
                ),
                const Gap.md(),
              ],
              AppButton(
                key: const Key('request_ride'),
                label: selectedRide == null
                    ? 'Escolha uma opção'
                    : 'Pedir ${selectedRide.name}',
                isLoading: viewModel.isRequesting,
                onPressed: viewModel.canRequest ? viewModel.requestRide : null,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _RideOptionCard extends StatelessWidget {
  const _RideOptionCard({
    required this.option,
    required this.selected,
    required this.onTap,
  });

  final RideOption option;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Semantics(
      button: true,
      selected: selected,
      label: '${option.name}, ${option.price}',
      child: InkWell(
        key: Key('ride_${option.id}'),
        onTap: onTap,
        borderRadius: AppRadius.mdAll,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          width: 132,
          padding: const EdgeInsets.all(AppSpacing.md),
          decoration: BoxDecoration(
            color: selected ? scheme.primaryContainer : scheme.surface,
            border: Border.all(
              color: selected ? scheme.primary : scheme.outline,
              width: selected ? 2 : 1,
            ),
            borderRadius: AppRadius.mdAll,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(option.icon, color: scheme.primary),
              const Spacer(),
              Text(option.name, style: Theme.of(context).textTheme.labelLarge),
              Text(option.price, style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
        ),
      ),
    );
  }
}

class _RequestConfirmed extends StatelessWidget {
  const _RequestConfirmed({required this.destination, required this.ride});

  final String destination;
  final RideOption ride;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      key: const Key('ride_requested'),
      width: double.infinity,
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(
        color: scheme.primaryContainer,
        borderRadius: AppRadius.mdAll,
      ),
      child: Text(
        '${ride.name} solicitado para $destination. Motorista a caminho em ${ride.arrival}.',
        style: Theme.of(context).textTheme.bodyMedium
            ?.copyWith(color: scheme.onPrimaryContainer),
      ),
    );
  }
}

class _MapPreview extends StatelessWidget {
  const _MapPreview();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return ColoredBox(
      color: scheme.primaryContainer,
      child: CustomPaint(
        painter: _MapPainter(
          roadColor: scheme.surface,
          routeColor: scheme.primary,
          landmarkColor: scheme.secondary.withValues(alpha: 0.25),
        ),
        child: const SizedBox.expand(),
      ),
    );
  }
}

class _MapPainter extends CustomPainter {
  const _MapPainter({
    required this.roadColor,
    required this.routeColor,
    required this.landmarkColor,
  });

  final Color roadColor;
  final Color routeColor;
  final Color landmarkColor;

  @override
  void paint(Canvas canvas, Size size) {
    final landmark = Paint()..color = landmarkColor;
    canvas.drawCircle(Offset(size.width * .2, size.height * .22), 72, landmark);
    canvas.drawCircle(
      Offset(size.width * .82, size.height * .42),
      98,
      landmark,
    );

    final road = Paint()
      ..color = roadColor
      ..strokeWidth = 18
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;
    final roads = [
      [
        Offset(-30, size.height * .18),
        Offset(size.width * .35, size.height * .44),
        Offset(size.width * .72, size.height * .2),
        Offset(size.width + 20, size.height * .32),
      ],
      [
        Offset(size.width * .1, -20),
        Offset(size.width * .28, size.height * .3),
        Offset(size.width * .62, size.height * .55),
        Offset(size.width * .92, size.height + 20),
      ],
      [
        Offset(-20, size.height * .62),
        Offset(size.width * .32, size.height * .52),
        Offset(size.width * .64, size.height * .78),
        Offset(size.width + 20, size.height * .7),
      ],
    ];
    for (final points in roads) {
      final path = Path()..moveTo(points.first.dx, points.first.dy);
      for (final point in points.skip(1)) {
        path.lineTo(point.dx, point.dy);
      }
      canvas.drawPath(path, road);
    }

    final route = Paint()
      ..color = routeColor
      ..strokeWidth = 6
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;
    final routePath = Path()
      ..moveTo(size.width * .32, size.height * .35)
      ..quadraticBezierTo(
        size.width * .48,
        size.height * .43,
        size.width * .6,
        size.height * .58,
      );
    canvas.drawPath(routePath, route);
    canvas.drawCircle(
      Offset(size.width * .32, size.height * .35),
      10,
      Paint()..color = routeColor,
    );
    canvas.drawCircle(
      Offset(size.width * .6, size.height * .58),
      12,
      Paint()..color = routeColor,
    );
  }

  @override
  bool shouldRepaint(_MapPainter oldDelegate) =>
      oldDelegate.roadColor != roadColor ||
      oldDelegate.routeColor != routeColor ||
      oldDelegate.landmarkColor != landmarkColor;
}

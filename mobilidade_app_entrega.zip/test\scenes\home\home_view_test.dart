import 'package:carteira_design_system/carteira_design_system.dart';
import 'package:carteira_digital/scenes/home/home_view.dart';
import 'package:carteira_digital/scenes/home/home_view_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

Widget _app() => MaterialApp(
  theme: AppTheme.light(),
  home: HomeView(viewModel: HomeViewModel()),
);

void main() {
  testWidgets('shows destination input and ride options', (tester) async {
    await tester.pumpWidget(_app());

    expect(find.byKey(const Key('home_destination')), findsOneWidget);
    expect(find.byKey(const Key('ride_move')), findsOneWidget);
    expect(find.byKey(const Key('ride_comfort')), findsOneWidget);
    expect(find.byKey(const Key('ride_moto')), findsOneWidget);
  });

  testWidgets('requests the selected ride for a destination', (tester) async {
    await tester.pumpWidget(_app());

    await tester.enterText(
      find.byKey(const Key('home_destination')),
      'Avenida Paulista, 1000',
    );
    await tester.tap(find.byKey(const Key('ride_move')));
    await tester.pump();
    await tester.tap(find.byKey(const Key('request_ride')));
    await tester.pump();
    await tester.pump(const Duration(seconds: 1));

    expect(find.byKey(const Key('ride_requested')), findsOneWidget);
    expect(
      find.descendant(
        of: find.byKey(const Key('ride_requested')),
        matching: find.textContaining('Avenida Paulista, 1000'),
      ),
      findsOneWidget,
    );
  });
}

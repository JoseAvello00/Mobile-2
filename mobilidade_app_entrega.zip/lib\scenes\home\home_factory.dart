import 'package:flutter/widgets.dart';

import 'home_view.dart';
import 'home_view_model.dart';

abstract final class HomeFactory {
  static Widget make() => HomeView(viewModel: HomeViewModel());
}

# Carteira Digital

Aplicativo Flutter de carteira digital, organizado por cenas e com um design
system reutilizável. O projeto usa MVVM na tela de login: a `View` observa a
`ViewModel`, enquanto o acesso ao servidor e a navegação entram por injeção de
dependências na `LoginFactory`.

## Estrutura

```text
lib/
  scenes/login/             # LoginScene (MVVM, Factory e Coordinator)
packages/design_system/     # tokens, tema, componentes e galeria
docs/api/                   # contrato da API
```

## Executar

```sh
flutter test
flutter run
cd packages/design_system/example && flutter run
```

Por padrão, o app usa um servidor local simulado para permitir o protótipo sem
backend. Credenciais de demonstração: `ana@carteira.dev` / `123456`.

O contrato do backend está em [docs/api/auth.md](docs/api/auth.md).

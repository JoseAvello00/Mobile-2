import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'ride_option.dart';

class HomeViewModel extends ChangeNotifier {
  HomeViewModel({List<RideOption>? options})
    : _options =
          options ??
          const [
            RideOption(
              id: 'move',
              name: 'Move',
              description: 'Mais próximo',
              price: r'R$ 12,40',
              arrival: '4 min',
              icon: RideIcon.car,
            ),
            RideOption(
              id: 'comfort',
              name: 'Comfort',
              description: 'Carros mais novos',
              price: r'R$ 17,90',
              arrival: '6 min',
              icon: RideIcon.comfort,
            ),
            RideOption(
              id: 'moto',
              name: 'Moto',
              description: 'Ágil para você',
              price: r'R$ 8,60',
              arrival: '3 min',
              icon: RideIcon.moto,
            ),
          ];

  final List<RideOption> _options;
  String _destination = '';
  RideOption? _selectedRide;
  bool _isRequesting = false;
  bool _rideRequested = false;

  List<RideOption> get options => List.unmodifiable(_options);
  String get destination => _destination;
  RideOption? get selectedRide => _selectedRide;
  bool get isRequesting => _isRequesting;
  bool get rideRequested => _rideRequested;
  bool get canRequest =>
      _destination.trim().isNotEmpty && _selectedRide != null;

  void updateDestination(String value) {
    _destination = value;
    _rideRequested = false;
    notifyListeners();
  }

  void selectRide(RideOption option) {
    _selectedRide = option;
    _rideRequested = false;
    notifyListeners();
  }

  Future<void> requestRide() async {
    if (!canRequest || _isRequesting) return;
    _isRequesting = true;
    notifyListeners();
    await Future<void>.delayed(const Duration(milliseconds: 800));
    _isRequesting = false;
    _rideRequested = true;
    notifyListeners();
  }
}

abstract final class RideIcon {
  static const car = Icons.directions_car_outlined;
  static const comfort = Icons.directions_car_filled_outlined;
  static const moto = Icons.two_wheeler_outlined;
}

import 'package:flutter/material.dart';

/// COMMON > Recursos em comum (cores)
/// Paleta central do Design System, agora com tema voltado para um
/// app de CORRIDA (dark mode + verde neon de "atividade" + laranja de
/// destaque para métricas de esforço). Nenhum componente deve usar
/// Color(...) "hardcoded" diretamente — sempre referenciar esta classe.
class AppColors {
  AppColors._();

  /// Verde "corrida em andamento" — cor de ação principal do app.
  static const Color primary = Color(0xFF00E676);
  static const Color primaryDark = Color(0xFF00B24A);

  /// Laranja usado para destacar métricas de esforço (ritmo, calorias).
  static const Color secondary = Color(0xFFFF6B35);

  /// Fundo escuro, comum em apps de corrida/fitness (Strava, Nike Run Club).
  static const Color background = Color(0xFF0D1117);
  static const Color surface = Color(0xFF161B22);
  static const Color surfaceElevated = Color(0xFF1F2733);

  static const Color textPrimary = Color(0xFFFFFFFF);
  static const Color textSecondary = Color(0xFF9CA3AF);

  /// Texto sobre o botão primário (verde) — precisa ser escuro para contraste.
  static const Color textOnPrimary = Color(0xFF0D1117);

  static const Color disabled = Color(0xFF374151);
  static const Color border = Color(0xFF30363D);
  static const Color error = Color(0xFFFF453A);
}

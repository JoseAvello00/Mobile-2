import 'package:flutter/widgets.dart';

/// COMPONENTS > ListItem > ViewModel
///
/// Guarda os dados de uma linha da lista (ex: uma corrida do histórico).
/// Segue o mesmo padrão do ActionButton e da TabBar: a ViewModel não sabe
/// desenhar nada, só carrega o estado.
class ListItemViewModel {
  final IconData leadingIcon;
  final String title;
  final String subtitle;

  /// Valor de destaque exibido à direita (ex: "5,2 km", "28 min").
  final String? trailingValue;

  /// Ícone de ação à direita (ex: seta ">"). Se [trailingValue] for
  /// informado, ele tem prioridade visual sobre o ícone.
  final IconData? trailingIcon;

  final VoidCallback? onTap;

  const ListItemViewModel({
    required this.leadingIcon,
    required this.title,
    required this.subtitle,
    this.trailingValue,
    this.trailingIcon,
    this.onTap,
  });

  ListItemViewModel copyWith({
    IconData? leadingIcon,
    String? title,
    String? subtitle,
    String? trailingValue,
    IconData? trailingIcon,
    VoidCallback? onTap,
  }) {
    return ListItemViewModel(
      leadingIcon: leadingIcon ?? this.leadingIcon,
      title: title ?? this.title,
      subtitle: subtitle ?? this.subtitle,
      trailingValue: trailingValue ?? this.trailingValue,
      trailingIcon: trailingIcon ?? this.trailingIcon,
      onTap: onTap ?? this.onTap,
    );
  }
}

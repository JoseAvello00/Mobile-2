import 'package:flutter/material.dart';
import '../../common/app_colors.dart';
import '../../common/app_spacing.dart';
import '../../common/app_text_styles.dart';
import 'list_item_view_model.dart';

/// COMPONENTS > ListItem > Component (View)
///
/// Widget "burro": desenha uma linha de lista (ícone + duas linhas de
/// texto + valor/ícone de destaque à direita). Não decide nada sozinho,
/// apenas lê a ViewModel — mesmo contrato do ActionButton e da TabBar.
///
/// Inspirado nas linhas repetidas de card (círculo + 2 linhas de texto +
/// elemento de destaque) que aparecem nas telas do Figma referencial.
class ListItemComponent extends StatelessWidget {
  final ListItemViewModel viewModel;

  const ListItemComponent({super.key, required this.viewModel});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
      onTap: viewModel.onTap,
      child: Container(
        padding: const EdgeInsets.all(AppSpacing.md),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: AppColors.primary.withValues(alpha: 0.15),
                shape: BoxShape.circle,
              ),
              child: Icon(
                viewModel.leadingIcon,
                color: AppColors.primary,
                size: 22,
              ),
            ),
            const SizedBox(width: AppSpacing.md),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    viewModel.title,
                    style: AppTextStyles.body.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 2),
                  Text(
                    viewModel.subtitle,
                    style: AppTextStyles.caption,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            const SizedBox(width: AppSpacing.sm),
            if (viewModel.trailingValue != null)
              Text(
                viewModel.trailingValue!,
                style: AppTextStyles.body.copyWith(
                  color: AppColors.secondary,
                  fontWeight: FontWeight.w700,
                ),
              )
            else if (viewModel.trailingIcon != null)
              Icon(
                viewModel.trailingIcon,
                color: AppColors.textSecondary,
                size: 18,
              ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'list_item_component.dart';
import 'list_item_view_model.dart';

/// COMPONENTS > ListItem > Factory
///
/// Padrão Factory Method: centraliza a criação do componente para os
/// casos de uso mais comuns do app de corrida, para as telas não
/// precisarem montar a ViewModel na mão toda vez.
class ListItemFactory {
  ListItemFactory._();

  /// Linha de "Atividade recente" (uma corrida já registrada no histórico).
  static Widget run({
    required String title,
    required String subtitle,
    required String distanceLabel,
    VoidCallback? onTap,
  }) {
    return ListItemComponent(
      viewModel: ListItemViewModel(
        leadingIcon: Icons.directions_run,
        title: title,
        subtitle: subtitle,
        trailingValue: distanceLabel,
        onTap: onTap,
      ),
    );
  }

  /// Linha genérica de navegação (ex: item de menu/configurações),
  /// com seta indicando que leva a outra tela.
  static Widget navigation({
    required IconData icon,
    required String title,
    required String subtitle,
    VoidCallback? onTap,
  }) {
    return ListItemComponent(
      viewModel: ListItemViewModel(
        leadingIcon: icon,
        title: title,
        subtitle: subtitle,
        trailingIcon: Icons.chevron_right,
        onTap: onTap,
      ),
    );
  }
}

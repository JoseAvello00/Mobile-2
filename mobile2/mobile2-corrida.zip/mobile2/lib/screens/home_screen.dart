import 'package:flutter/material.dart';
import '../common/app_colors.dart';
import '../common/app_spacing.dart';
import '../common/app_text_styles.dart';
import '../components/action_button/action_button_factory.dart';
import '../components/list_items/list_item_factory.dart';
import '../components/tab_bar/tab_bar_factory.dart';

/// SCREENS > HomeScreen
///
/// Dashboard principal do app de CORRIDA. Não implementa nenhuma lógica
/// de negócio própria (não calcula GPS, não persiste dados) — apenas
/// COMPÕE os componentes do Design System (ActionButton, TabBar,
/// ListItem) para provar que eles funcionam juntos em uma tela real,
/// seguindo a estrutura visual (cards arredondados, pílulas, ícone +
/// duas linhas de texto) observada no Figma referencial de wireframes.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedTab = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(
                  AppSpacing.lg,
                  AppSpacing.lg,
                  AppSpacing.lg,
                  AppSpacing.xl,
                ),
                children: [
                  _Header(),
                  const SizedBox(height: AppSpacing.lg),
                  ActionButtonFactory.primary(
                    label: 'Iniciar corrida',
                    icon: Icons.play_arrow_rounded,
                    onPressed: () {},
                  ),
                  const SizedBox(height: AppSpacing.lg),
                  Text('Hoje', style: AppTextStyles.heading),
                  const SizedBox(height: AppSpacing.md),
                  const _StatsRow(),
                  const SizedBox(height: AppSpacing.lg),
                  Text('Atividades recentes', style: AppTextStyles.heading),
                  const SizedBox(height: AppSpacing.md),
                  ListItemFactory.run(
                    title: 'Corrida matinal',
                    subtitle: 'Hoje, 07:32 · 28 min',
                    distanceLabel: '5,2 km',
                    onTap: () {},
                  ),
                  const SizedBox(height: AppSpacing.sm),
                  ListItemFactory.run(
                    title: 'Corrida no parque',
                    subtitle: 'Ontem, 18:10 · 41 min',
                    distanceLabel: '7,8 km',
                    onTap: () {},
                  ),
                  const SizedBox(height: AppSpacing.sm),
                  ListItemFactory.navigation(
                    icon: Icons.emoji_events_outlined,
                    title: 'Metas e conquistas',
                    subtitle: 'Veja seu progresso do mês',
                    onTap: () {},
                  ),
                ],
              ),
            ),
            TabBarFactory.standard(
              selectedIndex: _selectedTab,
              onTabSelected: (index) => setState(() => _selectedTab = index),
            ),
          ],
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header();

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Olá, corredor(a) 👋', style: AppTextStyles.caption),
              const SizedBox(height: 2),
              Text('Pronto para correr?', style: AppTextStyles.heading),
            ],
          ),
        ),
        Container(
          width: 44,
          height: 44,
          decoration: const BoxDecoration(
            color: AppColors.surface,
            shape: BoxShape.circle,
          ),
          child: const Icon(Icons.person_outline, color: AppColors.primary),
        ),
      ],
    );
  }
}

class _StatsRow extends StatelessWidget {
  const _StatsRow();

  @override
  Widget build(BuildContext context) {
    return Row(
      children: const [
        Expanded(
          child: _StatCard(value: '5,2', label: 'KM'),
        ),
        SizedBox(width: AppSpacing.sm),
        Expanded(
          child: _StatCard(value: '28', label: 'MIN'),
        ),
        SizedBox(width: AppSpacing.sm),
        Expanded(
          child: _StatCard(value: '5:23', label: 'MIN/KM'),
        ),
      ],
    );
  }
}

class _StatCard extends StatelessWidget {
  final String value;
  final String label;

  const _StatCard({required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: AppSpacing.md),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(AppSpacing.radiusMd),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: [
          Text(value, style: AppTextStyles.statValue),
          const SizedBox(height: 2),
          Text(label, style: AppTextStyles.statLabel),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import '../common/app_colors.dart';
import '../common/app_spacing.dart';
import '../common/app_text_styles.dart';
import '../components/list_items/list_item_factory.dart';

/// SCREENS > SampleListItemScreen
///
/// Tela de exemplo SEM lógica de negócio: existe só para provar,
/// visualmente, que o componente ListItem (View + ViewModel + Factory)
/// funciona nas suas duas variações (run / navigation).
class SampleListItemScreen extends StatelessWidget {
  const SampleListItemScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Sample: List Item')),
      body: ListView(
        padding: const EdgeInsets.all(AppSpacing.lg),
        children: [
          Text('Variação: run', style: AppTextStyles.heading),
          const SizedBox(height: AppSpacing.md),
          ListItemFactory.run(
            title: 'Corrida matinal',
            subtitle: 'Hoje, 07:32 · 28 min',
            distanceLabel: '5,2 km',
            onTap: () {},
          ),
          const SizedBox(height: AppSpacing.sm),
          ListItemFactory.run(
            title: 'Corrida no parque',
            subtitle: 'Ontem, 18:10 · 41 min',
            distanceLabel: '7,8 km',
            onTap: () {},
          ),
          const SizedBox(height: AppSpacing.lg),
          Text('Variação: navigation', style: AppTextStyles.heading),
          const SizedBox(height: AppSpacing.md),
          ListItemFactory.navigation(
            icon: Icons.emoji_events_outlined,
            title: 'Metas e conquistas',
            subtitle: 'Veja seu progresso do mês',
            onTap: () {},
          ),
          const SizedBox(height: AppSpacing.sm),
          ListItemFactory.navigation(
            icon: Icons.settings_outlined,
            title: 'Configurações',
            subtitle: 'Notificações, unidades, privacidade',
            onTap: () {},
          ),
        ],
      ),
    );
  }
}

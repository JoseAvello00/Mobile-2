# Mobile 2 — Design System Local (App de Corrida) 🏃

Design System local para um app de **corrida**, com componentes isolados da
lógica das telas, seguindo o padrão **ViewModel → Component → Factory**.

## 🔗 Figma Referencial
https://www.figma.com/design/aE5UvFW5gu3gcV1WBZDAiF/Wireframes-for-mobile-UI-design--Community-?node-id=35-0

Kit de wireframes de baixa fidelidade (telas em cinza, sem cor definida)
usado como planta baixa para a **estrutura** das telas: tab bar inferior
fixa, cards arredondados, linhas de lista com ícone + duas linhas de texto
+ valor de destaque, e botões em formato pílula. A paleta de cores (verde
de "corrida em andamento" + laranja de métricas de esforço) foi definida
em cima dessa estrutura, já que o kit original é monocromático.

## 📱 Como abrir no Android Studio

1. Abra o Android Studio → **Open** → selecione a pasta `mobile2/` (a raiz,
   onde está o `pubspec.yaml`).
2. Instale os plugins **Flutter** e **Dart** se ainda não tiver (Settings →
   Plugins).
3. O Android Studio vai pedir o caminho do Flutter SDK na primeira vez —
   aponte para onde você instalou o Flutter na sua máquina.
4. Rode `flutter pub get` (o próprio Android Studio oferece o botão, ou via
   terminal).
5. Selecione um emulador/dispositivo Android e clique em **Run**.

> A pasta `android/` já vem pronta (Gradle, Manifest, ícone). Só falta o
> `local.properties` apontar pro Flutter SDK da sua máquina — o Android
> Studio faz isso sozinho ao abrir o projeto.

## 🗂️ Como subir para o GitHub

Dentro da pasta `mobile2/` (raiz do projeto Flutter):

```bash
git init
git add .
git commit -m "Design System app de corrida - ActionButton, TabBar, ListItem"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/SEU_REPOSITORIO.git
git push -u origin main
```

Se o repositório já existe no GitHub (ex: este `Mobile-2`), clone-o antes,
copie os arquivos deste projeto por cima e faça:

```bash
git add .
git commit -m "Pivot para app de corrida + componente List Item"
git push
```

## 📁 Estrutura de pastas

```
lib/
├── main/
│   └── main.dart                 # ponto de entrada do app
├── common/                       # recursos em comum (cores, fontes, espaçamentos)
│   ├── app_colors.dart           # tema dark + verde/laranja de corrida
│   ├── app_text_styles.dart
│   └── app_spacing.dart
├── components/                   # componentes isolados e reutilizáveis
│   ├── action_button/
│   │   ├── action_button_view_model.dart
│   │   ├── action_button_component.dart
│   │   └── action_button_factory.dart
│   ├── tab_bar/
│   │   ├── tab_bar_view_model.dart
│   │   ├── tab_bar_component.dart
│   │   └── tab_bar_factory.dart
│   └── list_items/                # 3º componente (bônus), mesmo padrão
│       ├── list_item_view_model.dart
│       ├── list_item_component.dart
│       └── list_item_factory.dart
└── screens/
    ├── sample_screen.dart              # menu de navegação entre as amostras
    ├── sample_action_button_screen.dart
    ├── sample_tab_bar_screen.dart
    ├── sample_list_item_screen.dart
    └── home_screen.dart                # dashboard real do app de corrida,
                                         # compondo os 3 componentes juntos
```

## 🧩 Os componentes (ViewModel → Component → Factory)

| Componente | ViewModel | Component (View) | Factory |
|---|---|---|---|
| **Action Button** | `ActionButtonViewModel` guarda label, estilo (primário/secundário/destrutivo), estado (habilitado/carregando) e o callback | `ActionButtonComponent` só desenha o botão pílula de acordo com a ViewModel | `ActionButtonFactory.primary/.secondary/.destructive(...)` |
| **Tab Bar** | `TabBarViewModel` guarda a lista de abas, o índice selecionado e o callback de troca | `TabBarComponent` desenha a barra flutuante e delega o toque | `TabBarFactory.standard(...)` → Início / Corridas / Estatísticas / Perfil |
| **List Item** *(bônus)* | `ListItemViewModel` guarda ícone, título, subtítulo e valor/ícone de destaque | `ListItemComponent` desenha a linha (ícone + 2 textos + destaque) | `ListItemFactory.run(...)` para atividades, `.navigation(...)` para itens de menu |

## ▶️ Como rodar

```bash
flutter pub get
flutter run -t lib/main/main.dart
```

Ao abrir, a tela inicial (`SampleScreen`) lista as amostras de cada
componente e um botão **"Abrir app de corrida"**, que leva à `HomeScreen`
— o dashboard real com o botão "Iniciar corrida", os cards de estatísticas
do dia e o histórico de atividades recentes, tudo montado a partir dos
componentes do Design System.

## 📱 Telas de exemplo (prints aqui)

Adicione aqui os prints das telas rodando:

- `SampleScreen` — menu de navegação entre os componentes
- `SampleActionButtonScreen` — todos os estados do Action Button
- `SampleTabBarScreen` — Tab Bar funcionando e trocando de aba
- `SampleListItemScreen` — as duas variações do List Item
- `HomeScreen` — o app de corrida completo, componentes juntos

## 🏗️ Arquitetura

- **ViewModel**: guarda dados/estado do componente, sem nenhuma lógica de UI.
- **Component**: widget "burro" — só renderiza o que a ViewModel manda.
- **Factory**: método de criação (*Factory Method*) que monta ViewModel +
  Component prontos, para as telas não precisarem montar tudo na mão.

As telas (`screens/`) não têm lógica de negócio real (não há GPS, banco de
dados ou persistência): existem para provar que os componentes funcionam
isoladamente e, na `HomeScreen`, compostos juntos como um app de verdade.
